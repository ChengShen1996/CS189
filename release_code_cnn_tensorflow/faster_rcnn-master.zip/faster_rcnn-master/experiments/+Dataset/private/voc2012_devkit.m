function path = voc2012_devkit()
    path = './datasets/VOCdevkit2012';
end