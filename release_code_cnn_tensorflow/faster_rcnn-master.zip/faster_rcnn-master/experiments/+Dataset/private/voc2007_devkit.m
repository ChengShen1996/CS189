function path = voc2007_devkit()
    path = './datasets/VOCdevkit2007';
end